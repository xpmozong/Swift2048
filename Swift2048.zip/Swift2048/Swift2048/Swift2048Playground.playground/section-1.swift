// Playground - noun: a place where people can play

import UIKit

var button = UIButton()
button.setTitle("HelloWorld", forState:.Normal)
button.backgroundColor = UIColor.redColor()
button.titleLabel.textColor = UIColor.whiteColor()
button.frame = CGRectMake(0, 0, 200, 30)

